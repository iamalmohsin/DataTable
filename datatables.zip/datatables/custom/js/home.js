

/*$(document).ready(function()
{
 $("#myTable").DataTable();
});

$(document).ready(function(){
	$('table').DataTable();
});
*/



$(document).ready(function()
{
/*$("table").DataTable(); or else you can write like this or below one*/
 $("#mytables").DataTable();
});